module.exports = {
    database: "mongodb://localhost/recipe",
    secret: "secret"
};
